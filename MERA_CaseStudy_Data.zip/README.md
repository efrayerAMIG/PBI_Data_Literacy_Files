# PBI_Data_Literacy
This is a repository for Data Literacy Case Study Data and Power BI file
